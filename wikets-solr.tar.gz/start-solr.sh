#!/bin/sh
JAVA_HOME="/usr/lib/jvm/java-6-sun-1.6.0.30"
java -Dsolr.solr.home=multicore -jar start.jar
